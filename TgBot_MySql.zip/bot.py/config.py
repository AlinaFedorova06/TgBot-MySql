#API Token
API_TOKEN = '1403015492:AAF5RnUmzD_Uy9BRpmRYpe2TkjlgjqXquDs'

#Admin ID
admin_id = 624513451

#Database connection settings
dbHost = 'localhost'
dbUser = 'root'
dbPassword = '***********'
dbName = 'tBot'

